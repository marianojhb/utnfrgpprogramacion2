#include "Examen.h"

int main()
{
    Examen resolucion;

    /*
    El método EjemploDeListado muestra cómo se puede generar un listado de los registros a partir de los datos de
    restaurant.dat, se recomienda tomarlo de ejemplo para la resolución de los demás puntos.

    Tener en cuenta que deben entregar los archivos Examen.cpp y Examen.h con la resolución de los puntos solicitados.
    Todo código que quieran agregar para la resolución debe estar dentro de esos archivos.
    No modifiquen ninguno de los otros archivos ya que no tendrán permitido subir esos cambios en la entrega.
    */
    resolucion.EjemploDeListado();
    resolucion.Punto1();
    resolucion.Punto2();
    resolucion.Punto3();

    return 0;
}
